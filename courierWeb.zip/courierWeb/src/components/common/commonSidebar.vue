<template>
  <div class="sidebar">
    <el-menu :default-active="onRoute" class="sidebar-el-menu" :collapse="collapse" background-color="#fff" text-color="#333" active-text-color="#6190e8" router unique-opened>
      <template v-for="item in items">
        <template>
          <el-menu-item :index="item.index" :key="item.index" class="title">
            <!-- 预留字体图标 -->
            <i :class="item.icon"></i>
            <span slot="title" class="title">{{ item.title }}</span>
          </el-menu-item>
        </template>
      </template>
    </el-menu>
  </div>
</template>

<script>
import bus from '../../service/bus'
import { getRequest } from '../../utils/api'
export default {
  name: 'commonSidebar',
  data() {
    return {
      collapse: false,
      items: [],
    }
  },
  created() {
    // 控制折叠面板
    bus.$on('collapse', (msg) => {
      this.collapse = msg
      bus.$emit('collapse-content', msg)
    })
    this.getMenuList()
  },
  computed: {
    // 路由配置
    onRoute() {
      return this.$route.path.replace('/', '')
    },
  },
  methods: {
    getMenuList() {
      getRequest('/menu/list').then((res) => {
        this.items = res.data
      })
    },
  },
}
</script>

<style scoped>
.sidebar {
  display: block;
  position: absolute;
  left: 0;
  top: 70px;
  bottom: 0;
  overflow-y: scroll;
}
.sidebar::-webkit-scrollbar {
  width: 0;
}
.sidebar-el-menu:not(.el-menu--collapse) {
  width: 250px;
}
.sidebar > ul {
  height: 100%;
}

.title {
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.el-menu-item {
  border-left: #fff solid 6px;
}
/* 设置鼠标悬停时el-menu-item的样式 */
.el-menu-item:hover {
  border-left: #6190e8 solid 6px !important;
  background-color: #e2eff9 !important;
  color: #6190e8 !important;
}

.el-menu-item:hover i {
  color: #6190e8;
}

/* 设置选中el-menu-item时的样式 */
.el-menu-item.is-active {
  border-left: #6190e8 solid 6px !important;
  background-color: #e2eff9 !important;
  color: #6190e8 !important;
}
</style>
