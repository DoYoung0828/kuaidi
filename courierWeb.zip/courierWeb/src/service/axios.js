import axios from 'axios';
import router from '../router';
import { Message, MessageBox } from 'element-ui'


const BASE_URL = "/api"

// axios配置参数
axios.defaults.baseURL = BASE_URL
axios.defaults.timeout = 5000

// 请求拦截器
axios.interceptors.request.use(config => {
	config.withCredentials = true
	let token = localStorage.getItem("express_token")

	if (token) {
		config.headers['Authorization'] = token
	} else {
		router.push("/login")
	}
	if (config.method === 'get') {
		config.params = {
			t: Date.parse(new Date()) / 1000,
			...config.params
		}
	}
	// loadingPage = Loading.service(options);
	return config
},
	error => {
		// loadingPage.close()
		return Promise.reject(error)
	}
)

// respone拦截器
axios.interceptors.response.use(
	response => {
		/**
		* code为非200是抛错 可结合自己业务进行修改
		*/
		const res = response.data
		if (res.code !== 200) {
			Message({
				message: res.msg,
				type: 'error',
				duration: 3 * 1000
			})

			// 401:未登录;
			if (res.code === 401) {
				MessageBox.confirm('你已被登出，可以取消继续留在该页面，或者重新登录', '确定登出', {
					confirmButtonText: '重新登录',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					localStorage.clear()
					location.reload()// 为了重新实例化vue-router对象 避免bug
				})
			}
			return Promise.reject('error')
		} else {
			return response.data
		}
	},
	error => {
		console.log('err' + error)// for debug
		Message({
			message: error.message,
			type: 'error',
			duration: 3 * 1000
		})
		return Promise.reject(error)
	}
)

export default axios