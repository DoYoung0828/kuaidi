import axios from '../service/axios'
import qs from 'querystring'


/**
 * get请求
 * @param url
 * @param params
 * @returns {Promise<R>}
 */
export function getRequest(url, params) {
	return new Promise(async (resolve, reject) => {
		try {
			let query = await qs.stringify(params);
			let res = null;
			if (!params) {
				res = await axios.get(url);
			} else {
				res = await axios.get(url + '?' + query);
			}
			resolve(res);
		} catch (error) {
			let errorMsg = `请求报错路径： ${url} \n 请求错误信息: ${error}`;
			console.log(errorMsg)
			reject(error);
		}
	});
}

export function postRequest(url, data) {
	return new Promise(async (resolve, reject) => {
		try {
			let res = await axios.post(url, data);
			resolve(res);
		} catch (error) {
			let errorMsg = `请求报错路径：${url} \n 请求错误信息: ${error}`;
			reject(error);
		}
	});
}

/**
* PUT请求
* @param url
* @param params
* @returns {Promise<R>}
*/
export function putRequest(url, data) {
	return new Promise(async (resolve, reject) => {
		try {
			let res = await axios.put(url, data);
			resolve(res);
		} catch (error) {
			let errorMsg = `请求报错路径：${url} \n 请求错误信息: ${error}`;
			reject(error);
		}
	});
}

/**
* DELETE 请求
* @param url
* @param params
* @returns {Promise<R>}
*/
export function deleteRequest(url, data) {
	return new Promise(async (resolve, reject) => {
		try {
			let res = await axios.delete(url, data);
			resolve(res);
		} catch (error) {
			let errorMsg = `请求报错路径：${url} \n 请求错误信息: ${error}`;
			reject(error);
		}
	});
}

