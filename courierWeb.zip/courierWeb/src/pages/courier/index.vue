<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.username" clearable placeholder="请输入用户名"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="username" label="用户名"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="gender" label="性别"></el-table-column>
      <el-table-column prop="age" label="年龄"></el-table-column>
      <el-table-column prop="phone" label="电话"></el-table-column>
      <el-table-column prop="address" label="地址">
        <template slot-scope="scope">
          {{ scope.row.address | filterNull }}
        </template>
      </el-table-column>
      <el-table-column prop="lastLogin" label="最后登录时间"></el-table-column>
      <el-table-column label="操作" width="250">
        <template slot-scope="scope">
          <el-button size="mini" plain type="primary" @click="handleEdit(scope.row)">{{ scope.row.enableFlag ? '封禁' : '启用' }}</el-button>
          <el-button size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>
  </div>
</template>

<script>
import { deleteRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'courier',
  data() {
    return {
      query: {
        pageNo: 1,
        pageSize: 10,
        username: '',
      },
      list: [],
      total: 0,
      dialogVisible: false,
      dialogTitle: '',
      formData: {},
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未登记' : val
    },
  },
  created() {
    this.getList()
  },
  methods: {
    handleEdit(row) {
      if (row.enableFlag) {
        // 封禁
        row.enableFlag = false
      } else {
        row.enableFlag = true
      }
      const user = {
        id: row.userId,
        enableFlag: row.enableFlag,
      }
      putRequest('/user/enable', user).then(() => {
        this.$message.success('操作成功')
      })
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？（删除后快递员不可再登录）')
        .then(() => {
          deleteRequest('/user-info/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        username: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/user-info/courier/page', this.query).then((res) => {
        this.list = res.data.list
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
