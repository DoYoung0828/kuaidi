<template>
  <div class="container">
    <div style="margin-top: 20px">
      <el-row :gutter="15">
        <el-col :span="6">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>用户总数</span>
              <el-tooltip style="float: right" content="用户总数" placement="top-start">
                <i class="el-icon-user" style="color: #6190e8"></i>
              </el-tooltip>
            </div>
            <div style="font-size: 30px; color: #515a6e">{{ data.userTotal }}人</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>总快递数</span>
              <el-tooltip style="float: right" content="总快递数" placement="top-start">
                <i class="el-icon-document" style="color: #6190e8"></i>
              </el-tooltip>
            </div>
            <div style="font-size: 30px; color: #515a6e">{{ data.expressTotal }}单</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>今日收件</span>
              <el-tooltip style="float: right" content="今日收件" placement="top-start">
                <i class="el-icon-document" style="color: #6190e8"></i>
              </el-tooltip>
            </div>
            <div style="font-size: 30px; color: #515a6e">{{ data.pickTotal }}单</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>今日派件</span>
              <el-tooltip style="float: right" content="今日派件" placement="top-start">
                <i class="el-icon-document" style="color: #6190e8"></i>
              </el-tooltip>
            </div>
            <div style="font-size: 30px; color: #515a6e">{{ data.deliveryTotal }}单</div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <div style="margin-top: 20px">
      <el-row :gutter="15">
        <el-col :span="12">
          <el-card>
            <ve-line :data="chartData1"></ve-line>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card>
            <ve-histogram :data="chartData2"></ve-histogram>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { getRequest } from '../../utils/api'
export default {
  name: 'dashboard',
  data() {
    this.chartSettings = {
      metrics: ['收件数', '派件数'],
      dimension: ['日期'],
    }
    return {
      data: {},
      rows: {},
      chartData1: {
        columns: ['日期', '收件数', '派件数'],
        rows: [],
      },
      chartData2: {
        columns: ['日期', '收件数', '派件数'],
        rows: [],
      },
    }
  },
  created() {
    this.getStatics()
    this.getPickStatics()
  },
  methods: {
    getStatics() {
      getRequest('/role/statics').then((res) => {
        this.data = res.data
      })
    },
    getPickStatics() {
      getRequest('/role/pickAndDeliver').then((res) => {
        this.chartData1.rows = res.data.map(({ date, pickupCount, deliveryCount }) => ({
          '日期': `${new Date(date).getMonth() + 1}/${new Date(date).getDate()}`,
          '收件数': pickupCount,
          '派件数': deliveryCount,
        }))
        this.chartData2.rows = this.chartData1.rows
      })
    },
  },
}
</script>

<style scoped>
.card-item {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
</style>
