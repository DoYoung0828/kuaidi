<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.expressNo" clearable placeholder="请输入快递单号"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.receiverName" clearable placeholder="请输入姓名"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.expressCode" clearable placeholder="请输入取件码"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="success" icon="el-icon-edit" @click="handleEdit" v-if="roleId == 1">快递入库</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="expressNo" label="快递单号" width="180">
        <template slot-scope="scope">
          {{ filterText(scope.row.expressNo) }}
        </template>
      </el-table-column>
      <el-table-column prop="receiverName" label="收件人姓名" width="150">
        <template slot-scope="scope">
          {{ filterText(scope.row.receiverName) }}
        </template>
      </el-table-column>
      <el-table-column prop="receiverPhone" label="收件人号码" width="150">
        <template slot-scope="scope">
          {{ filterText(scope.row.receiverPhone) }}
        </template>
      </el-table-column>
      <el-table-column prop="receiverAddress" label="收件地址" width="150">
        <template slot-scope="scope">
          {{ filterText(scope.row.receiverAddress) }}
        </template>
      </el-table-column>
      <el-table-column prop="expressCode" label="取件码" width="100">
        <template slot-scope="scope">
          {{ filterText(scope.row.expressCode) }}
        </template>
      </el-table-column>
      <el-table-column prop="entryTime" label="入库时间" width="180"> </el-table-column>
      <el-table-column prop="outTime" label="出库时间" width="180">
        <template slot-scope="scope">
          {{ scope.row.outTime | filterNull }}
        </template>
      </el-table-column>
      <el-table-column prop="date" label="状态">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status == 0 ? 'warning' : 'success'">
            {{ scope.row.status == 0 ? '代取件' : '已出库' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="250" v-if="roleId != 3">
        <template slot-scope="scope">
          <el-button size="mini" plain type="success" v-if="!scope.row.status && roleId == 2" @click="dispatch(scope.row.id)">派遣无人机</el-button>
          <el-button size="mini" plain type="primary" v-if="roleId == 1 || roleId == 0" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" plain type="danger" v-if="roleId == 1 || roleId == 0" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="50%">
      <el-form ref="form" :model="formData" :rules="rules" label-width="80px" label-position="right">
        <el-form-item label="收件人姓名" prop="receiverName">
          <el-input v-model.trim="formData.receiverName" placeholder="请输入收件人姓名"></el-input>
        </el-form-item>
        <el-form-item label="收件人号码" prop="receiverPhone">
          <el-input v-model.trim="formData.receiverPhone" placeholder="请输入收件人号码"></el-input>
        </el-form-item>
        <el-form-item label="收件地址" prop="receiverAddress">
          <el-input v-model.trim="formData.receiverAddress" placeholder="请输入收件地址"></el-input>
        </el-form-item>
        <el-form-item label="取件码" prop="expressCode">
          <el-input v-model.trim="formData.expressCode" placeholder="请输入取件码"></el-input>
        </el-form-item>
        <el-form-item label="入库时间" prop="entryTime">
          <el-date-picker placeholder="请选择入库时间" value-format="yyyy-MM-dd HH:mm:ss" v-model="formData.entryTime" type="datetime" style="width: 100%" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </div>
    </el-dialog>

    <el-dialog title="调度" :visible.sync="droneDialog" width="30%">
      <div>
        <el-form ref="form" :model="form" label-width="120px" :rules="droneRules">
          <el-form-item label="派遣无人机" prop="dispatchDroneId">
            <el-select v-model="form.dispatchDroneId" placeholder="请选择无人机进行派遣">
              <el-option v-for="item in droneList" :key="item.id" :label="item.carType + ' - ' + item.carNo" :value="item.id"> </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer">
        <el-button @click="droneDialog = false">取 消</el-button>
        <el-button type="primary" @click="dispatchDrone">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, getRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'express',
  data() {
    return {
      roleId: null,
      query: {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
        expressCode: '',
        receiverName: '',
      },
      list: [],
      droneList: [],
      form: {
        dispatchDroneId: null,
      },
      currentCourierId: null,
      total: 0,
      droneDialog: false,
      dialogVisible: false,
      dialogTitle: '',
      formData: {},
      rules: {
        receiverName: [{ required: true, message: '请输入收件人姓名', trigger: 'blur' }],
        receiverAddress: [{ required: true, message: '请输入收件地址', trigger: 'blur' }],
        receiverPhone: [
          { required: true, message: '请输入收件人号码', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
        ],
        expressCode: [{ required: true, message: '请输入取件码', trigger: 'blur' }],
        entryTime: [{ required: true, message: '请选择入库时间', trigger: 'blur' }],
        outTime: [{ required: false, message: '请选择出库时间', trigger: 'blur' }],
      },
      droneRules: {
        dispatchDroneId: [{ required: true, message: '请选择派遣无人机', trigger: 'blur' }],
      },
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未出库' : val
    },
  },
  created() {
    this.getList()
    this.roleId = localStorage.getItem('express_roleId')
  },
  methods: {
    filterText(val) {
      if (this.roleId == 2) {
        return val.substring(0, 3) + '******'
      }
      return val
    },
    async dispatch(id) {
      const { data } = await getRequest('/car/user')
      this.droneList = data
      if (this.droneList.length == 0) {
        this.$message.warning('暂无空闲无人机可派遣')
        return
      }
      this.currentCourierId = id
      this.droneDialog = true
    },
    dispatchDrone() {
      this.$refs['form'].validate((res) => {
        if (res) {
          this.out()
          this.droneDialog = false
          this.currentCourierId = null
          this.form.dispatchDroneId = null
        }
      })
    },
    out() {
      putRequest('/express/out/' + this.currentCourierId + '/' + this.form.dispatchDroneId).then(() => {
        this.$message.success('派遣成功')
        this.getList()
      })
    },
    handleEdit(row) {
      if (row) {
        // 将需要编辑的数据赋值给formData，显示编辑弹窗
        this.dialogTitle = '编辑数据'
        this.formData = Object.assign({}, row)
      } else {
        this.dialogTitle = '快递入库'
        this.formData = {}
      }
      this.dialogVisible = true
      this.$refs.form.resetFields()
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？')
        .then(() => {
          deleteRequest('/express/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    handleSave() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // 根据是否有id判断是新增还是编辑
          if (this.formData.id) {
            putRequest('/express/update', this.formData).then(() => {
              const index = this.list.findIndex((item) => item.id === this.formData.id)
              Object.assign(this.list[index], this.formData)
              this.$message.success('编辑成功！')
            })
          } else {
            postRequest('/express/add', this.formData).then(() => {
              this.$message.success('成功入库一件快递')
              this.getList()
            })
          }
          this.dialogVisible = false
        } else {
          this.$message.error('表单校验失败，请检查输入信息！')
        }
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
        expressCode: '',
        receiverName: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/express/page', this.query).then((res) => {
        this.list = res.data.list
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
