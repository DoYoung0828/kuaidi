<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.username" clearable placeholder="请输入用户名"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="success" icon="el-icon-edit" @click="adminDialogVisible = true">添加</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="username" label="用户名"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="gender" label="性别">
        <template slot-scope="scope">
          {{ scope.row.gender | filterNull }}
        </template>
      </el-table-column>
      <el-table-column prop="age" label="年龄">
        <template slot-scope="scope">
          {{ scope.row.age | filterNull }}
        </template>
      </el-table-column>
      <el-table-column prop="phone" label="电话" width="120"></el-table-column>
      <el-table-column prop="address" label="地址">
        <template slot-scope="scope">
          {{ scope.row.address | filterNull }}
        </template>
      </el-table-column>
      <el-table-column prop="site" label="所属驿站"></el-table-column>
      <el-table-column label="权限配置">
        <template slot-scope="scope">
          <el-button type="text" @click="show(scope.row)">操作</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="lastLogin" label="最后登录时间" width="200"></el-table-column>
      <el-table-column label="操作" width="250">
        <template slot-scope="scope">
          <el-button size="mini" plain type="primary" @click="handleEdit(scope.row)">{{ scope.row.enableFlag ? '封禁' : '启用' }}</el-button>
          <el-button size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog title="权限配置" :visible.sync="dialogVisible" width="40%">
      <div>
        <el-tree v-if="dialogVisible" ref="tree" :props="menuProps" :data="menuData" :default-expand-all="true" show-checkbox node-key="id" :default-checked-keys="defaultMenu"> </el-tree>
      </div>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="changeMenu">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="添加驿站管理员" :visible.sync="adminDialogVisible" width="40%">
      <el-form :model="adminForm" :rules="adminRule" ref="adminForm">
        <el-form-item label="用户名" label-width="80px" prop="username">
          <el-input v-model.trim="adminForm.username"></el-input>
        </el-form-item>
        <el-form-item label="密码" label-width="80px" prop="password">
          <el-input v-model.trim="adminForm.password" type="password" :show-password="true"></el-input>
        </el-form-item>
        <el-form-item label="姓名" label-width="80px" prop="name">
          <el-input v-model.trim="adminForm.name"></el-input>
        </el-form-item>
        <el-form-item label="电话" label-width="80px" prop="phone">
          <el-input v-model.trim="adminForm.phone"></el-input>
        </el-form-item>
        <el-form-item label="所属驿站" prop="siteId">
          <el-select v-model="adminForm.siteId" placeholder="请选择驿站">
            <el-option v-for="item in siteList" :key="item.id" :label="item.siteName" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="adminDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addAdmin">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, getRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'setting',
  data() {
    return {
      query: {
        pageNo: 1,
        pageSize: 10,
        username: '',
      },
      adminDialogVisible: false,
      adminForm: {},
      currentUserId: null,
      list: [],
      siteList: [],
      total: 0,
      dialogVisible: false,
      dialogTitle: '',
      defaultMenu: [],
      menuData: {},
      menuProps: {
        label: 'name',
        id: 'id',
        disabled: 'disabled',
      },
      adminRule: {
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        phone: [
          { required: true, message: '请输入收件人号码', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
        ],
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        siteId: [{ required: true, message: '请选择驿站', trigger: 'blur' }],
      },
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未登记' : val
    },
  },
  created() {
    this.getList()
    this.getMenuList()
    this.getSiteList()
  },
  methods: {
    show(row) {
      getRequest('/menu/admin/' + row.userId).then((res) => {
        this.defaultMenu = res.data
        this.currentUserId = row.userId
        this.dialogVisible = true
        this.$forceUpdate()
      })
    },
    getMenuList() {
      getRequest('/menu/admin/list').then((res) => {
        this.menuData = res.data
      })
    },
    getSiteList() {
      getRequest('/express-site/all').then((res) => {
        this.siteList = res.data
      })
    },
    addAdmin() {
      this.$refs['adminForm'].validate((res) => {
        if (res) {
          postRequest('/user/add-admin', this.adminForm).then(() => {
            this.adminForm = {}
            this.adminDialogVisible = false
            this.$message.success('添加成功')
            this.getList()
          })
        }
      })
    },
    changeMenu() {
      const data = this.$refs['tree'].getCheckedKeys()
      if (this.currentUserId) {
        const param = {
          id: this.currentUserId,
          menuIds: data,
        }
        putRequest('/admin-menu/update', param).then(() => {
          this.$message.success('更新成功')
          this.currentUserId = null
          this.dialogVisible = false
        })
      }
    },
    handleEdit(row) {
      if (row.enableFlag) {
        // 封禁
        row.enableFlag = false
      } else {
        row.enableFlag = true
      }
      const user = {
        id: row.userId,
        enableFlag: row.enableFlag,
      }
      putRequest('/user/enable', user).then(() => {
        this.$message.success('操作成功')
      })
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？（删除后管理员不可再登录）')
        .then(() => {
          deleteRequest('/user-info/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        username: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/user-info/admin/page', this.query).then((res) => {
        this.list = res.data.list
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
