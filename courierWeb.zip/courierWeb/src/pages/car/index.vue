<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.carNo" clearable placeholder="请输入无人机编号"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.carType" clearable placeholder="请输入无人机型号"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="success" icon="el-icon-edit" @click="handleEdit">新增</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="carNo" label="无人机编号"></el-table-column>
      <el-table-column prop="carType" label="无人机型号"></el-table-column>
      <el-table-column prop="courierName" label="所属无人机管理员"></el-table-column>
      <el-table-column prop="carDescription" label="说明"></el-table-column>
      <el-table-column prop="isIdle" label="是否空闲">
        <template slot-scope="scope">
          <el-tag :type="scope.row.isIdle ? 'success' : 'warning'">
            {{ scope.row.isIdle ? '空闲' : '运作中' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="250">
        <template slot-scope="scope">
          <el-button size="mini" plain type="primary" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="50%">
      <el-form ref="form" :model="formData" :rules="rules" label-width="80px" label-position="right">
        <el-form-item label="无人机编号" prop="carNo">
          <el-input v-model.trim="formData.carNo" placeholder="请输入无人机编号"></el-input>
        </el-form-item>
        <el-form-item label="无人机类型" prop="carType">
          <el-input v-model.trim="formData.carType" placeholder="请输入无人机类型"></el-input>
        </el-form-item>
        <el-form-item label="说明" prop="carDescription">
          <el-input type="textarea" v-model.trim="formData.carDescription" placeholder="请输入说明"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, getRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'car',
  data() {
    return {
      query: {
        pageNo: 1,
        pageSize: 10,
        carNo: '',
        carType: '',
      },
      list: [],
      total: 0,
      dialogVisible: false,
      dialogTitle: '',
      formData: {},
      rules: {
        carNo: [{ required: true, message: '请输入车牌', trigger: 'blur' }],
        carType: [{ required: true, message: '请输入型号', trigger: 'blur' }],
        carDescription: [{ required: true, message: '请输入说明', trigger: 'blur' }],
        userId: [{ required: true, message: '请选择快递员', trigger: 'blur' }],
      },
      courierList: [],
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未出库' : val
    },
  },
  created() {
    this.getList()
    this.getCourierList()
  },
  methods: {
    successFile(res) {
      this.formData.img = res.data
      this.$forceUpdate()
    },
    handleEdit(row) {
      if (row) {
        // 将需要编辑的数据赋值给formData，显示编辑弹窗
        this.dialogTitle = '编辑数据'
        this.formData = Object.assign({}, row)
      } else {
        this.formData = {}
      }
      this.dialogVisible = true
      this.$refs.form.resetFields()
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？')
        .then(() => {
          deleteRequest('/car/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    handleSave() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // 根据是否有id判断是新增还是编辑
          if (this.formData.id) {
            putRequest('/car/', this.formData).then(() => {
              const index = this.list.findIndex((item) => item.id === this.formData.id)
              const cindex = this.courierList.findIndex((item) => item.id === this.formData.userId)
              Object.assign(this.list[index], this.formData)
              this.list[index].courierName = this.courierList[cindex].username
              this.$message.success('编辑成功！')
            })
          } else {
            postRequest('/car/', this.formData).then(() => {
              this.$message.success('新增成功')
              this.getList()
            })
          }
          this.dialogVisible = false
        } else {
          this.$message.error('表单校验失败，请检查输入信息！')
        }
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        carNo: '',
        carType: '',
      }
      this.getList()
    },
    getCourierList() {
      getRequest('/role/courier/list').then((res) => {
        this.courierList = res.data
      })
    },
    getList() {
      postRequest('/car/page', this.query).then((res) => {
        this.list = res.data.list
        this.list.forEach((item) => {
          item.srcList = []
          item.srcList.push(item.img)
        })
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
