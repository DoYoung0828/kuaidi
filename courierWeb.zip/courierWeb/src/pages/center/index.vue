<template lang="">
  <div class="app-container">
    <div>
      <el-card style="margin-bottom: 20px">
        <el-descriptions class="margin-top" title="个人信息" :column="3" size="medium" border>
          <template slot="extra">
            <el-button type="warning" size="small" @click="handleModifyInfo">修改信息</el-button>
          </template>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-user"></i>
              姓名
            </template>
            {{ userInfo.name | filterNull }}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-user"></i>
              性别
            </template>
            <el-tag type="primary">{{ userInfo.gender | filterNull }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-user"></i>
              年龄
            </template>
            <el-tag type="success">{{ userInfo.age | filterNull }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-mobile-phone"></i>
              手机号
            </template>
            {{ userInfo.phone | filterNull }}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-office-building"></i>
              联系地址
            </template>
            {{ userInfo.address | filterNull }}
          </el-descriptions-item>
          <el-descriptions-item v-if="userInfo.userId!==1" >
            <template slot="label">
              <i class="el-icon-eleme"></i>
              密码
            </template>
            {{ userInfo.password  }}
          </el-descriptions-item>
          <el-descriptions-item v-if="userInfo.userId!==1">
            <template slot="label">
              <i class="el-icon-help"></i>
              身份码
            </template>
            {{ userInfo.token  }}
          </el-descriptions-item>
        </el-descriptions>
      </el-card>
    </div>
    <el-dialog :visible.sync="dialogVisible" title="修改个人信息" width="50%" :before-close="handleClose">
      <el-form ref="modifyForm" :model="modifyInfo" :rules="rules" label-width="100px" class="margin-top">
        <el-form-item label="姓名" prop="name">
          <el-input v-model.trim="modifyInfo.name"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="gender">
          <el-radio-group v-model.trim="modifyInfo.gender">
            <el-radio-button label="男">男</el-radio-button>
            <el-radio-button label="女">女</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
          <el-input-number v-model.number.trim="modifyInfo.age" :min="18"></el-input-number>
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model.trim="modifyInfo.phone"></el-input>
        </el-form-item>
        <el-form-item label="联系地址" prop="address">
          <el-input v-model.trim="modifyInfo.address"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model.trim="modifyInfo.password"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSave">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { getRequest, putRequest } from '../../utils/api'
export default {
  name: 'center',
  data() {
    return {
      userInfo: {},
      dialogVisible: false,
      modifyInfo: {},
      rules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        gender: [{ required: true, message: '请选择性别', trigger: 'blur' }],
        age: [
          { required: true, message: '请输入年龄', trigger: 'blur' },
          { type: 'number', message: '年龄必须为数字值', trigger: 'blur' },
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
        ],
        address: [{ required: true, message: '请输入联系地址', trigger: 'blur' }],
      },
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未登记' : val
    },
  },
  created() {
    this.getUserInfo()
  },
  methods: {
    handleModifyInfo() {
      this.dialogVisible = true
      this.modifyInfo = Object.assign({}, this.userInfo)
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(done)
        .catch(() => {})
    },
    handleSave() {
      this.$refs.modifyForm.validate((valid) => {
        if (valid) {
          this.userInfo = Object.assign({}, this.modifyInfo)
          this.dialogVisible = false
          putRequest('/user-info/', this.userInfo).then(() => {
            this.$message.success('修改成功')
          })
        } else {
          return
        }
        this.$refs.modifyForm.resetFields()
      })
    },
    getUserInfo() {
      getRequest('/user-info/').then((res) => {
        this.userInfo = res.data
      })
    },
  },
}
</script>
<style lang=""></style>
