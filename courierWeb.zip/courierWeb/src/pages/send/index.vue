<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.expressNo" clearable placeholder="请输入快递单号"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table :header-cell-style="{ 'text-align': 'center' }" :cell-style="{ 'text-align': 'center' }" ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="expressNo" label="快递单号" width="240"></el-table-column>
      <el-table-column prop="name" label="无人机管理员" width="100"></el-table-column>
      <el-table-column prop="phone" label="联系电话电话" width="100"></el-table-column>
      <el-table-column prop="carId" label="无人机信息" width="100">
        <template slot-scope="scope">
          <el-button type="text" @click="getCar(scope.row.car)">查看</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="expressStatus" label="快递状态" width="100">
        <template slot-scope="scope">
          <el-tag :type="scope.row.expressStatus | showStatus">{{ scope.row.expressStatus | filterExpressStatus }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createdTime" label="送出时间" width="200"></el-table-column>
      <el-table-column prop="endTime" label="送达时间" width="200">
        <template slot-scope="scope">
          {{ scope.row.endTime | filterNull }}
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200">
        <template slot-scope="scope">
          <el-button v-if="scope.row.expressStatus == 0 && roleId == 3" size="mini" plain type="primary" @click="confirmSend(scope.row)">确认送达</el-button>
          <el-button v-if="scope.row.expressStatus == 1 || scope.row.expressStatus == 2" size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog title="无人机信息" :visible.sync="carDialogVisible" width="40%">
      <el-table :data="carList" style="width: 100%">
        <el-table-column label="无人机名称" width="180">
          <template slot-scope="scope">
            <i class="el-icon-time"></i>
            <span style="margin-left: 10px">{{ scope.row.carNo }}</span>
          </template>
        </el-table-column>
        <el-table-column label="无人机型号" prop="carType"></el-table-column>
        <el-table-column label="说明" prop="carDescription"></el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, getRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'send',
  data() {
    return {
      roleId: null,
      query: {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
      },
      carList: [],
      list: [],
      total: 0,
      dialogVisible: false,
      carDialogVisible: false,
      dialogTitle: '',
      formData: {},
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未送达' : val
    },
    filterExpressStatus(val) {
      switch (val) {
        case 0:
          return '未送达'
        case 1:
          return '已送达'
        default:
          return '暂未登记'
      }
    },
    showStatus(val) {
      if (val == 0) {
        return 'info'
      } else if (val == 1) {
        return 'success'
      } else {
        return 'warning'
      }
    },
  },
  created() {
    this.getList()
    this.roleId = localStorage.getItem('express_roleId')
  },
  methods: {
    getCar(car) {
      console.log('car :>> ', car)
      this.carList = [car]
      this.carDialogVisible = true
    },
    confirmSend(row) {
      row.expressStatus = 1
      putRequest('/delivery/success/', row).then((res) => {
        this.getList()
        this.$message.success('已确认送达')
      })
    },
    handleEdit(row) {
      if (row) {
        // 将需要编辑的数据赋值给formData，显示编辑弹窗
        this.dialogTitle = '编辑数据'
        this.formData = Object.assign({}, row)
      } else {
        this.formData = {}
      }
      this.dialogVisible = true
      this.$refs.form.resetFields()
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？')
        .then(() => {
          deleteRequest('/pickup/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    handleSave() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // 根据是否有id判断是新增还是编辑
          if (this.formData.id) {
            putRequest('/pickup/update', this.formData).then(() => {
              const index = this.list.findIndex((item) => item.id === this.formData.id)
              Object.assign(this.list[index], this.formData)
              this.$message.success('编辑成功！')
            })
          } else {
            postRequest('/pickup/user/add', this.formData).then(() => {
              this.$message.success('下单成功')
              this.getList()
            })
          }
          this.dialogVisible = false
        } else {
          this.$message.error('表单校验失败，请检查输入信息！')
        }
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/delivery/page', this.query).then((res) => {
        this.list = res.data.list
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
