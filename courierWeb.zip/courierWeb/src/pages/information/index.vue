<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.title" clearable placeholder="请输入标题"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.informationType" clearable placeholder="请输入类型"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="success" icon="el-icon-edit" @click="handleEdit" v-if="roleId == 1 || roleId == 0">新增</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="title" lrabel="标题"></el-table-column>
      <el-table-column prop="informationType" label="类型"></el-table-column>
      <el-table-column label="图片">
        <template slot-scope="scope">
          <el-image lazy style="width: 50px; height: 50px; border-radius: 5px" :src="scope.row.img" :preview-src-list="scope.row.srcList"></el-image>
        </template>
      </el-table-column>
      <el-table-column prop="description" label="描述"></el-table-column>
      <el-table-column prop="createdTime" label="发布时间"></el-table-column>
      <el-table-column label="操作" width="250" v-if="roleId == 1 || roleId == 0">
        <template slot-scope="scope">
          <el-button size="mini" plain type="primary" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" plain type="danger" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="50%">
      <el-form ref="form" :model="formData" :rules="rules" label-width="80px" label-position="right">
        <el-form-item label="标题" prop="title">
          <el-input v-model.trim="formData.title" placeholder="请输入标题"></el-input>
        </el-form-item>
        <el-form-item label="类型" prop="informationType">
          <el-input v-model.trim="formData.informationType" placeholder="请输入类型"></el-input>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input type="textarea" v-model.trim="formData.description" placeholder="请输入描述"></el-input>
        </el-form-item>
        <el-form-item label="上传图片" prop="img">
          <el-upload action="http://localhost:12345/upload/img" :on-success="successFile" :show-file-list="false" list-type="picture">
            <img width="100px" v-if="formData.img" :src="formData.img" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'information',
  data() {
    return {
      query: {
        pageNo: 1,
        pageSize: 10,
        title: '',
        informationType: '',
      },
      list: [],
      roleId: null,
      total: 0,
      dialogVisible: false,
      dialogTitle: '',
      formData: {
        img: '',
      },
      rules: {
        title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
        informationType: [{ required: true, message: '请输入类型', trigger: 'blur' }],
        description: [{ required: true, message: '请输入描述', trigger: 'blur' }],
        img: [{ required: true, message: '请上传图片', trigger: 'blur' }],
      },
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未出库' : val
    },
  },
  created() {
    this.getList()
    this.roleId = localStorage.getItem('express_roleId')
  },
  methods: {
    successFile(res) {
      this.formData.img = res.data
      this.$forceUpdate()
    },
    handleEdit(row) {
      if (row) {
        // 将需要编辑的数据赋值给formData，显示编辑弹窗
        this.dialogTitle = '编辑数据'
        this.formData = Object.assign({}, row)
      } else {
        this.formData = {}
      }
      this.dialogVisible = true
      this.$refs.form.resetFields()
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？')
        .then(() => {
          deleteRequest('/information/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    handleSave() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // 根据是否有id判断是新增还是编辑
          if (this.formData.id) {
            putRequest('/information/update', this.formData).then(() => {
              const index = this.list.findIndex((item) => item.id === this.formData.id)
              Object.assign(this.list[index], this.formData)
              this.$message.success('编辑成功！')
            })
          } else {
            postRequest('/information/add', this.formData).then(() => {
              this.$message.success('新增成功')
              this.getList()
            })
          }
          this.dialogVisible = false
        } else {
          this.$message.error('表单校验失败，请检查输入信息！')
        }
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
        expressCode: '',
        receiverName: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/information/page', this.query).then((res) => {
        this.list = res.data.list
        this.list.forEach((item) => {
          item.srcList = []
          item.srcList.push(item.img)
        })
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
