<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item>
        <el-input size="mini" v-model="query.expressNo" clearable placeholder="请输入快递单号"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.receiverName" clearable placeholder="请输入收件人姓名"></el-input>
      </el-form-item>
      <el-form-item>
        <el-input size="mini" v-model="query.expressCompany" clearable placeholder="请输入快递公司"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="success" icon="el-icon-edit" @click="handleEdit" v-if="roleId == 3">下单寄件</el-button>
      </el-form-item>
    </el-form>
    <el-table :header-cell-style="{ 'text-align': 'center' }" :cell-style="{ 'text-align': 'center' }" ref="multipleTable" :data="list" tooltip-effect="dark" style="width: 100%">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="expressNo" label="快递单号" width="250"></el-table-column>
      <el-table-column prop="username" label="下单用户" width="100"></el-table-column>
      <el-table-column prop="receiverName" label="收件人姓名" width="100"></el-table-column>
      <el-table-column prop="receiverPhone" label="收件人号码" width="150"></el-table-column>
      <el-table-column prop="receiverAddress" label="收件人地址" width="200"></el-table-column>
      <el-table-column prop="pickupName" label="寄件人姓名" width="100"></el-table-column>
      <el-table-column prop="pickupPhone" label="寄件人号码" width="150"></el-table-column>
      <el-table-column prop="pickupAddress" label="寄件地址" width="200"></el-table-column>
      <el-table-column prop="itemNo" label="货柜号" width="200"></el-table-column>
      <el-table-column prop="expressCompany" label="快递公司" width="100"></el-table-column>
      <el-table-column prop="amount" label="运费" width="60"></el-table-column>
      <el-table-column prop="orderTime" label="下单时间" width="150"></el-table-column>
      <el-table-column prop="status" label="订单状态" width="200">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status | showStatus">{{ scope.row.status | expressStatus }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="物流状态">
        <template slot-scope="scope">
          <el-button type="text" @click="showLogistics(scope.row)">查看</el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="400">
        <template slot-scope="scope">
          <el-button size="mini" plain type="success" v-if="roleId == 1 && scope.row.status == 2" @click="authSuccess(scope.row)">审核通过</el-button>
          <el-button size="mini" plain type="error" v-if="roleId == 1 && scope.row.status == 2" @click="authFail(scope.row)">审核失败</el-button>
          <el-button size="mini" plain type="warning" v-if="roleId == 1 && scope.row.status == 1" @click="confirmRe(scope.row)">确认送达</el-button>
          <el-button size="mini" plain type="warning" v-if="roleId == 1 && scope.row.status == 3" @click="sendExpress(scope.row)">寄出</el-button>
          <el-button size="mini" plain type="primary" v-if="roleId == 2 && scope.row.status == 0" @click="dispatch(scope.row.id)">派遣无人机</el-button>
          <el-button size="mini" plain type="primary" v-if="roleId == 0 || roleId == 1" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" plain type="danger" v-if="roleId == 0 || roleId == 1" @click="handleDelete(scope.$index, scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="50%">
      <el-form ref="form" :model="formData" :rules="rules" label-width="120px" label-position="right">
        <el-form-item label="寄件人姓名" prop="pickupName">
          <el-input v-model.trim="formData.pickupName" placeholder="请输入寄件人姓名"></el-input>
        </el-form-item>
        <el-form-item label="寄件人号码" prop="pickupPhone">
          <el-input v-model.trim="formData.pickupPhone" placeholder="请输入寄件人号码"></el-input>
        </el-form-item>
        <el-form-item label="寄件地址" prop="pickupAddress">
          <el-input v-model.trim="formData.pickupAddress" placeholder="请输入寄件地址"></el-input>
        </el-form-item>
        <el-form-item label="收件人姓名" prop="receiverName">
          <el-input v-model.trim="formData.receiverName" placeholder="请输入收件人姓名"></el-input>
        </el-form-item>
        <el-form-item label="收件人号码" prop="receiverPhone">
          <el-input v-model.trim="formData.receiverPhone" placeholder="请输入收件人号码"></el-input>
        </el-form-item>
        <el-form-item label="收货地址" prop="receiverAddress">
          <el-input v-model.trim="formData.receiverAddress" placeholder="请输入收货地址"></el-input>
        </el-form-item>
        <el-form-item label="货柜号" prop="itemNo">
          <el-input v-model.trim="formData.itemNo" placeholder="请输入格式：x号楼xx号货柜"></el-input>
        </el-form-item>
        <el-form-item label="快递公司" prop="expressCompany">
          <el-select v-model="formData.expressCompany" placeholder="请选择快递公司" @change="formData.amount = 15">
            <el-option v-for="item in options" :key="item" :label="item" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="金额" prop="amount">
          <el-input-number :disabled="true" v-model.trim="formData.amount" :min="5" :max="100" />
        </el-form-item>
        <el-form-item label="下单时间" prop="orderTime">
          <el-date-picker placeholder="请选择下单时间" value-format="yyyy-MM-dd HH:mm:ss" v-model="formData.orderTime" type="datetime" style="width: 100%" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </div>
    </el-dialog>

    <el-dialog title="物流信息" :visible.sync="logDialogVisible" width="40%">
      <template slot="title" v-if="roleId == 1 || roleId == 0">
        <el-button type="text" size="medium" @click="logEnable = false">更新</el-button>
      </template>
      <el-form ref="logForm" :model="logFormData" :rules="logRules" label-width="80px" label-position="right">
        <el-form-item label="发货时间" prop="deliveryTime">
          <el-date-picker :disabled="logEnable" placeholder="暂未登记" value-format="yyyy-MM-dd HH:mm:ss" v-model="logFormData.deliveryTime" type="datetime" style="width: 100%" />
        </el-form-item>
        <el-form-item label="当前位置" prop="currentLocation">
          <el-input :disabled="logEnable" v-model.trim="logFormData.currentLocation" placeholder="暂未登记" />
        </el-form-item>
        <el-form-item label="当前状态" prop="currentStatus">
          <el-select :disabled="logEnable" v-model="logFormData.currentStatus" placeholder="暂未登记">
            <el-option :label="'已揽收'" :value="0" />
            <el-option :label="'运输中'" :value="1" />
            <el-option :label="'派送中'" :value="2" />
            <el-option :label="'已签收'" :value="3" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button
          @click="
            logDialogVisible = false
            logEnable = true
          "
          >取消</el-button
        >
        <el-button type="primary" @click="handleLogSave" :disabled="logEnable">保存</el-button>
      </div>
    </el-dialog>

    <el-dialog title="调度" :visible.sync="droneDialog" width="30%">
      <div>
        <el-form ref="form" :model="form" label-width="120px" :rules="droneRules">
          <el-form-item label="派遣无人机" prop="dispatchDroneId">
            <el-select v-model="form.dispatchDroneId" placeholder="请选择无人机进行派遣">
              <el-option v-for="item in droneList" :key="item.id" :label="item.carType + ' - ' + item.carNo" :value="item.id"> </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer">
        <el-button @click="droneDialog = false">取 消</el-button>
        <el-button type="primary" @click="dispatchDrone">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { deleteRequest, getRequest, postRequest, putRequest } from '../../utils/api'
export default {
  name: 'pick',
  data() {
    return {
      roleId: null,
      query: {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
        expressCode: '',
        receiverName: '',
      },
      list: [],
      total: 0,
      dialogVisible: false,
      logDialogVisible: false,
      logEnable: true,
      dialogTitle: '',
      logFormData: {},
      formData: {},
      droneDialog: false,
      droneList: [],
      currentExpressId: null,
      form: {
        dispatchDroneId: null,
      },
      rules: {
        expressNo: [{ required: true, message: '请输入快递单号', trigger: 'blur' }],
        pickupName: [{ required: true, message: '请输入寄件人姓名', trigger: 'blur' }],
        pickupPhone: [
          { required: true, message: '请输入寄件人号码', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
        ],
        pickupAddress: [{ required: true, message: '请输入寄件地址', trigger: 'blur' }],
        receiverName: [{ required: true, message: '请输入收件人姓名', trigger: 'blur' }],
        itemNo: [{ required: true, message: '请输入货柜号', trigger: 'blur' }],
        receiverPhone: [
          { required: true, message: '请输入收件人号码', trigger: 'blur' },
          { pattern: /^1[3456789]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' },
        ],
        receiverAddress: [{ required: true, message: '请输入收件地址', trigger: 'blur' }],
        expressCompany: [{ required: true, message: '请选择快递公司', trigger: 'blur' }],
        orderTime: [{ required: true, message: '请选择下单时间', trigger: 'blur' }],
      },
      logRules: {
        deliveryTime: [{ required: true, message: '请选择下单时间', trigger: 'blur' }],
        currentLocation: [{ required: true, message: '请输入当前位置', trigger: 'blur' }],
        currentStatus: [{ required: true, message: '请选择当前状态', trigger: 'blur' }],
      },
 
      droneRules: {
        dispatchDroneId: [{ required: true, message: '请选择派遣无人机', trigger: 'blur' }],
      },
      options: ['中通快递', '圆通快递', '顺丰快递', '申通快递', '韵达快递'],
    }
  },
  filters: {
    filterNull(val) {
      return val == null ? '暂未出库' : val
    },
    showStatus(val) {
      if (val == 0) {
        return 'info'
      } else if (val == 1) {
        return 'success'
      } else {
        return 'warning'
      }
    },
    expressStatus(val) {
      switch (val) {
        case 0:
          return '待无人机取件'
        case 1:
          return '已取件，待送达'
        case 2:
          return '已送达，待审核'
        case 3:
          return '已审核，待寄出'
        case 4:
          return '已寄出'
        default:
          return '审核未通过'
      }
    },
  },
  created() {
    this.getList()
    this.roleId = localStorage.getItem('express_roleId')
  },
  methods: {
    confirmRe(item) {
      item.status = 2
      putRequest('/pickup/update', row).then(() => {
        const index = this.list.findIndex((item) => item.id === this.formData.id)
        Object.assign(this.list[index], this.formData)
        this.$message.success('审核已通过！')
      })
    },
    async dispatch(id) {
      const { data } = await getRequest('/car/user')
      this.droneList = data
      if (this.droneList.length == 0) {
        this.$message.warning('暂无空闲无人机可派遣')
        return
      }
      this.currentExpressId = id
      this.droneDialog = true
    },
    dispatchDrone() {
      this.$refs['form'].validate((res) => {
        if (res) {
          postRequest('/pickup/drone/' + this.form.dispatchDroneId + '/' + this.currentExpressId).then(() => {
            this.droneDialog = false
            this.currentCourierId = null
            this.form.dispatchDroneId = null
            this.$message.success('派遣无人机成功')
            this.getList()
          })
        }
      })
    },
    showLogistics(item) {
      if (item.status != 4) {
        this.$message.warning('暂未寄出，无物流信息')
        return
      }
      this.logFormData = { ...item.logistics }
      this.logFormData.pickExpressId = item.id
      this.logDialogVisible = true
    },
    authSuccess(row) {
      row.status = 3
      putRequest('/pickup/update', row).then(() => {
        this.$message.success('审核已通过！')
      })
    },
    authFail(row) {
      row.status = 5
      putRequest('/pickup/update', row).then(() => {
        this.$message.success('操作成功')
      })
    },
    sendExpress(row) {
      if (row.authStatus == 2) {
        this.$message.error('审核未通过，无法寄出')
        return
      }
      postRequest('/pickup/admin/add', row).then(() => {
        this.$message.success('已寄出')
        this.getList()
      })
    },
    handleEdit(row) {
      if (row.status == 4) {
        this.$message.warning('快递已寄出，无法编辑！')
        return
      }
      if (row) {
        // 将需要编辑的数据赋值给formData，显示编辑弹窗
        this.dialogTitle = '编辑数据'
        this.formData = Object.assign({}, row)
      } else {
        this.formData = {}
      }
      this.dialogVisible = true
      this.$refs.form.resetFields()
    },
    handleDelete(index, id) {
      // 弹出确认提示框，确认删除则删除该行数据
      this.$confirm('是否删除该条数据？')
        .then(() => {
          deleteRequest('/pickup/' + id).then(() => {
            this.list.splice(index, 1)
            this.total--
            this.$message.success('删除成功！')
          })
        })
        .catch(() => {})
    },
    handleSave() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // 根据是否有id判断是新增还是编辑
          if (this.formData.id) {
            putRequest('/pickup/update', this.formData).then(() => {
              const index = this.list.findIndex((item) => item.id === this.formData.id)
              Object.assign(this.list[index], this.formData)
              this.$message.success('编辑成功！')
            })
          } else {
            postRequest('/pickup/user/add', this.formData).then(() => {
              this.$message.success('下单成功')
              this.getList()
            })
          }
          this.dialogVisible = false
        } else {
          this.$message.error('表单校验失败，请检查输入信息！')
        }
      })
    },
    handleLogSave() {
      this.$refs.logForm.validate((valid) => {
        if (valid) {
          postRequest('/logistics-info/update', this.logFormData).then(() => {
            this.$message.success('更新成功')
            this.getList()
            this.logDialogVisible = false
          })
        }
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        expressNo: '',
        receiverName: '',
        expressCompany: '',
      }
      this.getList()
    },
    getList() {
      postRequest('/pickup/page', this.query).then((res) => {
        this.list = res.data.list
        this.total = res.data.total
      })
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
  },
}
</script>

<style scoped></style>
