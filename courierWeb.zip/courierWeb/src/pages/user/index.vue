<template>
  <div class="container">
    <el-form :inline="true" :model="query" class="demo-form-inline">
      <el-form-item label="姓名">
        <el-input v-model="query.name" clearable></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="getList">搜索</el-button>
      </el-form-item>
      <el-form-item>
        <el-button type="warning" icon="el-icon-refresh" @click="reset">重置</el-button>
      </el-form-item>
      <el-form-item>
        <el-button type="success" icon="el-icon-edit">新增</el-button>
      </el-form-item>
    </el-form>
    <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="gender" label="性别"></el-table-column>
      <el-table-column prop="age" label="年龄"></el-table-column>
      <el-table-column prop="phone" label="电话"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
      <el-table-column prop="updatedTime" label="最后登录时间"></el-table-column>
      <el-table-column label="操作" width="200">
        <template>
          <el-button size="mini" plain type="primary">编辑</el-button>
          <el-button size="mini" plain type="danger">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="query.pageNo" :page-size="query.pageSize" layout="total,  prev, pager, next, jumper" :total="total"></el-pagination>
    </div>
  </div>
</template>

<script>
import {getRequest } from '../../utils/api'
export default {
  name: 'btable',
  data() {
    return {
      tableData: [],
      query: {
        pageNo: 1,
        pageSize: 10,
        name:""
      },
      total: null,
      currentPage4: 0,
    }
  },
  created(){
    this.getList()
  },
  methods: {
    getList() {
      getRequest('/user-info/getUserList',this.query).then((res) => {
          console.log("rww",res);
        this.tableData = res.data.list
        this.total = res.data.total
      })
    },
    reset() {
      this.query = {
        pageNo: 1,
        pageSize: 10,
        name: '',
      }
      this.getList()
    },
    handleSizeChange(val) {
      this.query.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.query.pageNo = val
      this.getList()
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
  },
}
</script>

<style scoped></style>
