import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/',
			redirect: '/login'
		},
		{
			path: '/',
			component: () => import('../components/Home.vue'),
			meta: { title: 'home' },
			children: [
				{
					path: 'dashboard',
					component: () => import('@/pages/dashboard'),
					meta: { title: '系统首页' }
				},
				{
					path: 'center',
					component: () => import('@/pages/center'),
					meta: { title: '个人信息' }
				},
				{
					path: 'information',
					component: () => import('@/pages/information'),
					meta: { title: '资讯信息' }
				},
				{
					path: 'courier',
					component: () => import('@/pages/courier'),
					meta: { title: '快递员信息' }
				},
				{
					path: 'car',
					component: () => import('@/pages/car'),
					meta: { title: '车辆信息' }
				},
				{
					path: 'user',
					component: () => import('@/pages/user'),
					meta: { title: '用户信息' }
				},
				{
					path: 'pick',
					component: () => import('@/pages/pick'),
					meta: { title: '寄件中心' }
				},
				{
					path: 'send',
					component: () => import('@/pages/send'),
					meta: { title: '派件中心' }
				},
				{
					path: 'express',
					component: () => import('@/pages/express'),
					meta: { title: '快递中心' }
				},
				{
					path: 'setting',
					component: () => import('@/pages/setting'),
					meta: { title: '权限配置' }
				}
			]
		},
		{
			path: '/login',
			component: () => import('../pages/login'),
			meta: { title: '登录' }
		}
	]
})