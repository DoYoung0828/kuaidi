module.exports = {

	devServer: {
		open: false,
		proxy: {
			'/api': {
				target: 'http://192.168.5.49:12345',
				changeOrigin: true,
				pathRewrite: { '^/api': '' }
			}
		}
	}
}